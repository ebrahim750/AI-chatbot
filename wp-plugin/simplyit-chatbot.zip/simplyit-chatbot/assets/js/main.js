jQuery(function ($) {
    // Chat widget position configuration: 'left' or 'right'
    const CHAT_POSITION = 'right';
    
    // Positioning configuration (pixels)
    // Horizontal offset from edge (left or right depending on CHAT_POSITION)
    const CHAT_HORIZONTAL_OFFSET_DESKTOP = 50;
    const CHAT_HORIZONTAL_OFFSET_MOBILE = 16;
    
    // Vertical offset from bottom (in pixels)
    const CHAT_FAB_VERTICAL_OFFSET_DESKTOP = 50;     // bottom-6 ≈ 24px
    const CHAT_FAB_VERTICAL_OFFSET_MOBILE = 20;
    
    // Gap between FAB bottom and window bottom (in pixels)
    const CHAT_WINDOW_FAB_GAP_DESKTOP = 72;  // 96 - 24
    const CHAT_WINDOW_FAB_GAP_MOBILE = 60;   // 80 - 20
    
    // Chat widget primary color (hex)
    const CHAT_COLOR = '#dd3a0a';
    
    // FAB button label text
    const FAB_LABEL = 'Need help?';
    
    // FAB button subtitle text
    const FAB_SUBTITLE = 'AI Assistant';
    
    // Enable/disable pulsing animation (true/false)
    const FAB_PULSE_ENABLED = true;
    
    // Enable/disable typing animation for AI responses (true/false)
    const TYPING_ANIMATION_ENABLED = true;
    
    // Typing speed for AI responses (milliseconds per character)
    const TYPING_SPEED = 2;
    
    // Chat header label text
    const HEADER_LABEL = 'S.A.M (Simply Ask Me)';
    
    // User chat bubble color (hex)
    const USER_BUBBLE_COLOR = '#3d2e2e';
    
    // User chat text color (hex)
    const USER_TEXT_COLOR = '#ffffff';
    
    // Welcome message
    const WELCOME_MESSAGE = 'Hi! I am SAM, how may I be of assistance?\n Have any questions about SimplyIT?\n Or would you like to book a free audit for your business?';
    
    const $root = $('#simplyit-chatbot');
    const assetsBase = $root.data('assetsUrl') || '';
    const imageBase = assetsBase ? `${assetsBase}/img` : 'img';
    const $window = $('#chat-window');
    const $fab = $('#chat-fab');
    const $form = $('#chat-form');
    const $input = $('#chat-input');
    const $messages = $('#chat-messages');
    const $snackbar = $('#error-snackbar');
    const $errorMessage = $('#error-message');
    const $errorDismiss = $('#error-dismiss');
    const $fabLabel = $('#chat-fab-label');
    const $fabSubtitle = $('#chat-fab-subtitle');
    const $headerLabel = $('#header-label');
    const $headerSubtitle = $('#header-subtitle');
    const $sendBtn = $('#chat-send');
    let isWaitingForResponse = false;
    
    // Set FAB label and subtitle text
    $fabLabel.text(FAB_LABEL);
    $fabSubtitle.text(FAB_SUBTITLE);
    
    // Set header label and subtitle
    $headerLabel.text(HEADER_LABEL);
    $headerSubtitle.text(FAB_SUBTITLE);
    
    // Initialize visibility - hide skeleton, show actual content, show FAB
    $('#chat-skeleton').hide();
    $('#chat-content').removeClass('simplyit-chatbot-hidden').show();
    $fab.css('visibility', 'visible');
    if (FAB_PULSE_ENABLED) {
        $fab.addClass('chat-fab-pulse');
    }
    $window.css('visibility', 'visible');
    
    // Store typing indicator color (default tailwind:indigo-500)
    let typingDotRgb = '99, 102, 241';
    
    // Helper function to convert hex to RGB
    function hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }
    
    // Apply custom color to elements
    function applyChatColor(color) {
        const rgb = hexToRgb(color);
        if (!rgb) return;
        
        const rgbString = `${rgb.r}, ${rgb.g}, ${rgb.b}`;
        // Store for typing indicator
        typingDotRgb = rgbString;
        
        // FAB button
        $fab.css('background-color', color);
        $fab.css('box-shadow', `0 10px 15px -3px rgba(${rgbString}, 0.3)`);
        $fab.hover(function() {
            $(this).css('background-color', `rgba(${rgbString}, 0.9)`);
        }, function() {
            $(this).css('background-color', color);
        });
        
        // Header
        $('#chat-content > div:first-child').css('background-color', color);
        
        // Send button
        $('#chat-send').css('background-color', color);
        $('#chat-send').hover(function() {
            $(this).css('background-color', `rgba(${rgbString}, 0.9)`);
        }, function() {
            $(this).css('background-color', color);
        });
        
        // Input focus
        $input.on('focus', function() {
            $(this).css('border-color', color);
            $(this).css('box-shadow', `0 0 0 3px rgba(${rgbString}, 0.2)`);
        });
        $input.on('blur', function() {
            $(this).css('border-color', '#e2e8f0');
            $(this).css('box-shadow', '0 1px 2px 0 rgb(0 0 0 / 0.05)');
        });
        
        // Avatar for assistant messages
        $(document).on('DOMNodeInserted', function(e) {
            const $el = $(e.target);
        $el.find('.simplyit-chatbot-bg-indigo-600').css('background-color', color);
        });
    }
    
    // Apply colors
    applyChatColor(CHAT_COLOR);
    
    // Apply pulse color using already-converted RGB (lighter/transparent)
    if (FAB_PULSE_ENABLED) {
        document.documentElement.style.setProperty('--chat-pulse-color', `rgba(${typingDotRgb}, 0.4)`);
    }
    
     function clearMobileViewportOverrides() {
         const windowEl = $window[0];
         if (!windowEl) return;

         windowEl.style.removeProperty('top');
         windowEl.style.removeProperty('bottom');
         windowEl.style.removeProperty('height');
     }

     // Positioning function for desktop/mobile responsive offsets
     function updatePositioning() {
         const isMobile = window.innerWidth < 640; // sm breakpoint
         const windowEl = $window[0];
         const hOffset = isMobile ? CHAT_HORIZONTAL_OFFSET_MOBILE : CHAT_HORIZONTAL_OFFSET_DESKTOP;
         const fabVOffset = isMobile ? CHAT_FAB_VERTICAL_OFFSET_MOBILE : CHAT_FAB_VERTICAL_OFFSET_DESKTOP;
         const gap = isMobile ? CHAT_WINDOW_FAB_GAP_MOBILE : CHAT_WINDOW_FAB_GAP_DESKTOP;
          // Calculate window bottom offset
          let winVOffset = fabVOffset + gap;
          
          const side = CHAT_POSITION; // 'left' or 'right'
          
          // Apply to chat window
          if (isMobile) {
              if (windowEl) {
                  windowEl.style.setProperty('transition-duration', '0ms');
              }
              // On mobile, always full screen when open
              if ($window.hasClass('simplyit-chatbot-opacity-100')) {
                  $window.css({
                      left: '0',
                      right: '0',
                      top: '0',
                      bottom: '0',
                      width: '100vw',
                      height: '100dvh',
                      marginLeft: '0',
                      marginRight: '0',
                      borderRadius: '0'
                  });
                  handleKeyboard();
              }
          } else {
              if (windowEl) {
                  windowEl.style.removeProperty('transition-duration');
              }
              clearMobileViewportOverrides();
              // On desktop, position based on config
              $window.css({
                  [side]: hOffset + 'px',
                  bottom: winVOffset + 'px',
                  left: '',
                  right: '',
                  top: '',
                  width: '',
                  height: '',
                  borderRadius: ''
              });
          }
          
          // Apply to FAB
          $fab.css({
              [side]: hOffset + 'px',
              bottom: fabVOffset + 'px'
          });
          
           // Mobile: manage expanded class based on window state
           if (isMobile) {
               if ($window.hasClass('simplyit-chatbot-opacity-100')) {
                   // Open: ensure expanded
                   if (!$window.hasClass('chat-expanded')) {
                       $window.addClass('chat-expanded');
                   }
               } else {
                   // Closed: remove expanded to keep small size
                   if ($window.hasClass('chat-expanded')) {
                       $window.removeClass('chat-expanded');
                   }
               }
           }
           
           // Handle FAB visibility on mobile
           if (isMobile) {
               if ($window.hasClass('simplyit-chatbot-opacity-100')) {
                   $fab.addClass('fab-mobile-hidden');
               } else {
                   $fab.removeClass('fab-mobile-hidden');
               }
           } else {
               // On desktop, ensure FAB is visible
               $fab.removeClass('fab-mobile-hidden');
           }
       }
       
       // Keep chat window aligned to the visual viewport when the keyboard appears.
       function handleKeyboard() {
           const isMobile = window.innerWidth < 640;
           if (!isMobile) return;
           if (!$window.hasClass('chat-fullscreen')) return;
           
           const viewport = window.visualViewport;
           if (!viewport) return;

           const windowEl = $window[0];
           if (!windowEl) return;

           const viewportHeight = Math.max(0, Math.round(viewport.height));
           const viewportTop = Math.max(0, Math.round(viewport.offsetTop || 0));

           // Use !important because .chat-fullscreen rules also use !important.
           windowEl.style.setProperty('top', `${viewportTop}px`, 'important');
           windowEl.style.setProperty('height', `${viewportHeight}px`, 'important');
           windowEl.style.setProperty('bottom', 'auto', 'important');
       }
       
       if (window.visualViewport) {
           window.visualViewport.addEventListener('resize', handleKeyboard);
           window.visualViewport.addEventListener('scroll', handleKeyboard);
       }
    
    // Initial positioning
    updatePositioning();
    
    // Update on window resize
    $(window).on('resize', updatePositioning);

    function focusComposer() {
        const inputEl = $input[0];
        if (!inputEl) return;
        inputEl.focus({ preventScroll: true });
    }

    function generateChatId() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        const array = new Uint32Array(32);
        window.crypto.getRandomValues(array);
        for (let i = 0; i < 32; i++) {
            result += chars[array[i] % chars.length];
        }
        return result;
    }

    let chatId = localStorage.getItem('chatId') || generateChatId();
    localStorage.setItem('chatId', chatId);

    // Chat history management with localStorage
    const CHAT_STORAGE_KEY = 'chatbot_history';
    let chatHistory = [];

    function saveChatHistory() {
        localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(chatHistory));
    }

    function loadChatHistory() {
        const saved = localStorage.getItem(CHAT_STORAGE_KEY);
        if (saved) {
            try {
                chatHistory = JSON.parse(saved);
                renderChatHistory();
            } catch (e) {
                console.error('Failed to load chat history:', e);
                chatHistory = [];
            }
        }
    }

    function renderChatHistory() {
        $messages.empty();
        chatHistory.forEach(message => {
            appendMessageToDOM(message, false);
        });
        setTimeout(() => {
            $messages.scrollTop($messages.prop('scrollHeight'));
        }, 0);
    }

    function clearChatHistory() {
        chatId = generateChatId();
        localStorage.setItem('chatId', chatId);
        chatHistory = [];
        localStorage.removeItem(CHAT_STORAGE_KEY);
        $messages.empty();
        // Add welcome message
        appendMessage({ text: WELCOME_MESSAGE, role: 'assistant' });
    }

     function toggleWindow(show) {
         const isMobile = window.innerWidth < 640;
         const openClass = isMobile
             ? 'simplyit-chatbot-opacity-100 simplyit-chatbot-pointer-events-auto'
             : 'simplyit-chatbot-opacity-100 simplyit-chatbot-scale-100 simplyit-chatbot-pointer-events-auto';
         const closedClass = isMobile
             ? 'simplyit-chatbot-opacity-0 simplyit-chatbot-pointer-events-none'
             : 'simplyit-chatbot-opacity-0 simplyit-chatbot-scale-95 simplyit-chatbot-pointer-events-none';
         $window.removeClass('simplyit-chatbot-scale-95 simplyit-chatbot-scale-100');
         
         if (show === true) {
             $window.removeClass(closedClass);
             $window.addClass(openClass);
             if (isMobile) {
                 $window.addClass('chat-fullscreen');
                 // Prevent body scroll on mobile
                 $('body').css('overflow', 'hidden');
                 setTimeout(handleKeyboard, 0);
             }
             focusComposer();
         } else if (show === false) {
             $window.removeClass(openClass);
             $window.addClass(closedClass);
             $window.removeClass('chat-fullscreen');
             clearMobileViewportOverrides();
             $('body').css('overflow', '');
         } else {
             if ($window.hasClass('simplyit-chatbot-opacity-0')) {
                 $window.removeClass(closedClass);
                 $window.addClass(openClass);
                 if (isMobile) {
                     $window.addClass('chat-fullscreen');
                     $('body').css('overflow', 'hidden');
                     setTimeout(handleKeyboard, 0);
                 }
                 focusComposer();
             } else {
                 $window.removeClass(openClass);
                 $window.addClass(closedClass);
                 $window.removeClass('chat-fullscreen');
                 clearMobileViewportOverrides();
                 $('body').css('overflow', '');
             }
         }
         // Update FAB visibility and positioning after toggle
         updatePositioning();
     }

    function appendMessage({ text, role, scroll = true, typing = false }) {
        // Add to chat history
        const message = { text, role, timestamp: Date.now() };
        chatHistory.push(message);
        saveChatHistory();
        
        // Render to DOM
        if (typing && TYPING_ANIMATION_ENABLED && role === 'assistant') {
            appendMessageWithTyping(message, scroll);
        } else {
            appendMessageToDOM(message, scroll);
        }
    }

    function appendMessageWithTyping(message, scroll = true) {
        const { text, role } = message;
        const isUser = role === 'user';
        const avatar = isUser
            ? `<img src="${imageBase}/user.jpg" class="simplyit-chatbot-mt-1 simplyit-chatbot-h-7 simplyit-chatbot-w-7 simplyit-chatbot-flex-shrink-0 simplyit-chatbot-rounded-full simplyit-chatbot-ring-2 simplyit-chatbot-ring-white simplyit-chatbot-object-cover simplyit-chatbot-bg-white">`
            : `<img src="${imageBase}/bot.jpg" class="simplyit-chatbot-mt-1 simplyit-chatbot-h-7 simplyit-chatbot-w-7 simplyit-chatbot-flex-shrink-0 simplyit-chatbot-rounded-full simplyit-chatbot-ring-2 simplyit-chatbot-ring-white simplyit-chatbot-object-cover simplyit-chatbot-bg-white">`;

        const bubbleStyle = isUser ? `background-color: ${USER_BUBBLE_COLOR}; color: ${USER_TEXT_COLOR}` : '';
        const bubbleClasses = isUser
            ? 'simplyit-chatbot-rounded-br-sm'
            : 'simplyit-chatbot-bg-white simplyit-chatbot-text-slate-800 simplyit-chatbot-ring-1 simplyit-chatbot-ring-slate-200 simplyit-chatbot-rounded-tl-sm';

        const containerClasses = isUser ? 'simplyit-chatbot-justify-end' : '';
        
        const content = `
            <div class="simplyit-chatbot-mb-3 simplyit-chatbot-flex simplyit-chatbot-gap-2 ${containerClasses}">
                ${isUser ? '' : avatar}
                <div class="simplyit-chatbot-max-w-[85%] simplyit-chatbot-rounded-2xl simplyit-chatbot-px-3 simplyit-chatbot-py-2 simplyit-chatbot-text-sm simplyit-chatbot-shadow ${bubbleClasses} ${isUser ? '' : 'formatted-content'}" style="${bubbleStyle}"><span class="typing-text"></span></div>
                ${isUser ? avatar : ''}
            </div>
        `;
        $messages.append(content);
        
        const $typingEl = $messages.find('.typing-text').last();
        let userScrolledUp = false;
        
        $messages.on('scroll', function() {
            const maxScroll = $(this).prop('scrollHeight') - $(this).outerHeight();
            const isNearBottom = $(this).scrollTop() >= maxScroll - 10;
            if (!isNearBottom) {
                userScrolledUp = true;
            } else {
                userScrolledUp = false;
            }
        });
        
        function typeNextChar(index) {
            if (index < text.length) {
                const partialText = text.substring(0, index + 1);
                const partialHtml = formatMarkdown(partialText);
                $typingEl.html(partialHtml);
                
                if (!userScrolledUp) {
                    $messages.scrollTop($messages.prop('scrollHeight'));
                }
                setTimeout(() => typeNextChar(index + 1), TYPING_SPEED);
            }
        }
        
        typeNextChar(0);
    }

    // Initialize Showdown converter
    const markdownConverter = new showdown.Converter({
        tables: true,
        openLinksInNewWindow: true,
        linkTarget: '_blank'
    });

    function formatMarkdown(text) {
        return markdownConverter.makeHtml(text);
    }

    function markMessageFailed($messageEl, text) {
        $messageEl.find('.message-failed').remove();
        const failedHtml = `<div class="message-failed simplyit-chatbot-mt-1 simplyit-chatbot-text-xs simplyit-chatbot-text-red-500 simplyit-chatbot-cursor-pointer hover:simplyit-chatbot-underline" style="text-align: right;">Message failed to send. <span class="simplyit-chatbot-text-red-600 simplyit-chatbot-font-medium">Click to resend</span></div>`;
        $messageEl.append(failedHtml);
        $messageEl.find('.message-failed').on('click', function(e) {
            e.stopPropagation();
            $(this).remove();
            sendMessage(text);
        });
    }

    function appendMessageToDOM(message, scroll = true) {
        const { text, role } = message;
        const isUser = role === 'user';
        const avatar = isUser
            ? `<img src="${imageBase}/user.jpg" class="simplyit-chatbot-mt-1 simplyit-chatbot-h-7 simplyit-chatbot-w-7 simplyit-chatbot-flex-shrink-0 simplyit-chatbot-rounded-full simplyit-chatbot-ring-2 simplyit-chatbot-ring-white simplyit-chatbot-object-cover simplyit-chatbot-bg-white">`
            : `<img src="${imageBase}/bot.jpg" class="simplyit-chatbot-mt-1 simplyit-chatbot-h-7 simplyit-chatbot-w-7 simplyit-chatbot-flex-shrink-0 simplyit-chatbot-rounded-full simplyit-chatbot-ring-2 simplyit-chatbot-ring-white simplyit-chatbot-object-cover simplyit-chatbot-bg-white">`;

        const bubbleStyle = isUser ? `background-color: ${USER_BUBBLE_COLOR}; color: ${USER_TEXT_COLOR}` : '';
        const bubbleClasses = isUser
            ? 'simplyit-chatbot-rounded-br-sm'
            : 'simplyit-chatbot-bg-white simplyit-chatbot-text-slate-800 simplyit-chatbot-ring-1 simplyit-chatbot-ring-slate-200 simplyit-chatbot-rounded-tl-sm';

        const containerClasses = isUser ? 'simplyit-chatbot-justify-end' : '';
        
        // Format text based on role
        const displayText = isUser ? $('<div>').text(text).html().replace(/\n/g, '<br>') : formatMarkdown(text);
        
        const content = `
            <div class="simplyit-chatbot-mb-3 simplyit-chatbot-flex simplyit-chatbot-flex-col ${containerClasses}">
                <div class="simplyit-chatbot-flex simplyit-chatbot-gap-2 ${isUser ? 'simplyit-chatbot-justify-end' : ''}">
                    ${isUser ? '' : avatar}
                    <div class="simplyit-chatbot-max-w-[85%] simplyit-chatbot-rounded-2xl simplyit-chatbot-px-3 simplyit-chatbot-py-2 simplyit-chatbot-text-sm simplyit-chatbot-shadow ${bubbleClasses} ${isUser ? '' : 'formatted-content'}" style="${bubbleStyle}">${displayText}</div>
                    ${isUser ? avatar : ''}
                </div>
            </div>
        `;
        $messages.append(content);
        if (scroll) {
            $messages.scrollTop($messages.prop('scrollHeight'));
        }
    }

    function showThinkingIndicator() {
        const dotStyle = `style="background-color: rgb(${typingDotRgb})"`;
        const content = `
            <div class="simplyit-chatbot-mb-3 simplyit-chatbot-flex simplyit-chatbot-gap-2" id="thinking-indicator">
                <img src="${imageBase}/bot.jpg" class="simplyit-chatbot-mt-1 simplyit-chatbot-h-7 simplyit-chatbot-w-7 simplyit-chatbot-flex-shrink-0 simplyit-chatbot-rounded-full simplyit-chatbot-ring-2 simplyit-chatbot-ring-white simplyit-chatbot-object-cover simplyit-chatbot-bg-white">
                <div class="simplyit-chatbot-max-w-[75%] simplyit-chatbot-rounded-2xl simplyit-chatbot-rounded-tl-sm simplyit-chatbot-bg-white simplyit-chatbot-px-3 simplyit-chatbot-py-2 simplyit-chatbot-text-sm simplyit-chatbot-text-slate-800 simplyit-chatbot-ring-1 simplyit-chatbot-ring-slate-200 simplyit-chatbot-shadow">
                    <span class="thinking"><span class="thinking-dot" ${dotStyle}></span><span class="thinking-dot" ${dotStyle}></span><span class="thinking-dot" ${dotStyle}></span></span>
                </div>
            </div>
        `;
        $messages.append(content);
        $messages.scrollTop($messages.prop('scrollHeight'));
    }

    function hideThinkingIndicator() {
        $('#thinking-indicator').remove();
    }

    function scrollToLastUserMessage() {
        const $lastUserMsg = $messages.find('.simplyit-chatbot-justify-end').last();
        if ($lastUserMsg.length) {
            $lastUserMsg[0].scrollIntoView({ block: 'start', behavior: 'instant' });
        }
    }

    // Initialize chat history on page load
    loadChatHistory();
    if (chatHistory.length === 0) {
        appendMessage({ text: WELCOME_MESSAGE, role: 'assistant' });
    }

    // Resize functionality
    function toggleResize() {
        $window.toggleClass('chat-expanded');
        const isExpanded = $window.hasClass('chat-expanded');
        
        // Update resize button icon
        const resizeIcon = $('#chat-resize svg');
        if (isExpanded) {
            // Show minimize icon when expanded
            resizeIcon.html('<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>');
            $('#chat-resize').attr('data-tooltip', 'Make chat smaller');
        } else {
            // Show expand icon when normal
            resizeIcon.html('<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>');
            $('#chat-resize').attr('data-tooltip', 'Make chat bigger');
        }
        
        // Scroll to bottom after resize
        setTimeout(() => {
            $messages.scrollTop($messages.prop('scrollHeight'));
         }, 100);
     }

     // Snackbar error notification
     function showErrorSnackbar(message) {
         $errorMessage.text(message);
         $snackbar.removeClass('simplyit-chatbot-hidden').addClass('show');
         
         // Auto-hide after 30 seconds
         setTimeout(() => {
             hideErrorSnackbar();
         }, 30000);
     }

     function hideErrorSnackbar() {
         $snackbar.removeClass('show');
         setTimeout(() => {
             $snackbar.addClass('simplyit-chatbot-hidden');
         }, 300);
     }

     // Dismiss button handler
     $errorDismiss.on('click', hideErrorSnackbar);

    // Toggle handlers
    $fab.on('click', () => {
        $fab.removeClass('chat-fab-pulse');
        toggleWindow();
    });
    $('#chat-close').on('click', () => toggleWindow(false));
    $('#chat-resize').on('click', () => toggleResize());
    $('#chat-clear').on('click', () => {
        if (confirm('Are you sure you want to clear the chat history? The AI will forget your conversation.')) {
            clearChatHistory();
        }
    });

    // Submit handler
    $form.on('submit', function (e) {
        e.preventDefault();
        const text = $input.val().trim();
        if (!text || isWaitingForResponse) return;

        sendMessage(text);
    });

    function sendMessage(text) {
        isWaitingForResponse = true;
        $sendBtn.prop('disabled', true);
        $input.val(text);

        appendMessage({ text, role: 'user' });
        $input.val('');

        let typingTimeout = setTimeout(() => {
            showThinkingIndicator();
        }, 1000);

        const wpConfig = window.SimplyITChatbot || null;
        const useWpAjax = wpConfig && wpConfig.ajaxUrl;
        const ajaxConfig = useWpAjax
            ? {
                url: wpConfig.ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: {
                    action: 'simplyit_chatbot_message',
                    nonce: wpConfig.nonce || '',
                    message: text,
                    chat_id: chatId
                }
            }
            : {
                url: 'api.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ message: text, chat_id: chatId })
            };

        $.ajax({
            ...ajaxConfig,
            success: function(response) {
                clearTimeout(typingTimeout);
                hideThinkingIndicator();
                hideErrorSnackbar();
                const reply = response && response.response
                    ? response.response
                    : (response && response.data && response.data.response ? response.data.response : null);
                if (!reply) {
                    showErrorSnackbar('An error occurred, please try again.');
                    isWaitingForResponse = false;
                    $sendBtn.prop('disabled', false);
                    return;
                }
                appendMessage({ text: reply, role: 'assistant', scroll: false, typing: true });
                isWaitingForResponse = false;
                $sendBtn.prop('disabled', false);
            },
            error: function(xhr, status, error) {
                clearTimeout(typingTimeout);
                hideThinkingIndicator();
                console.error('Chat API error:', { status, error, response: xhr.responseJSON });
                showErrorSnackbar('An error occurred, please try again.');
                
                const $allMessages = $messages.children('.simplyit-chatbot-mb-3');
                const $lastUserMsgContainer = $allMessages.last();
                const $lastUserMsg = $lastUserMsgContainer.find('.simplyit-chatbot-justify-end').last();
                
                if ($lastUserMsg.length) {
                    $lastUserMsgContainer.find('.message-failed').remove();
                    const failedHtml = `<div class="message-failed simplyit-chatbot-mt-1 simplyit-chatbot-text-xs simplyit-chatbot-text-red-500 simplyit-chatbot-cursor-pointer hover:simplyit-chatbot-underline" style="text-align: right;">Message failed to send. <span class="simplyit-chatbot-text-red-600 simplyit-chatbot-font-medium">Click to resend</span></div>`;
                    $lastUserMsgContainer.append(failedHtml);
                    $lastUserMsgContainer.find('.message-failed').on('click', function(e) {
                        e.stopPropagation();
                        $(this).remove();
                        sendMessage(text);
                    });
                    scrollToLastUserMessage();
                }
                
                isWaitingForResponse = false;
                $sendBtn.prop('disabled', false);
            }
        });
    }

    // Enter to send, Shift+Enter for newline
    $input.on('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey && !isWaitingForResponse) {
            e.preventDefault();
            $form.trigger('submit');
        }
    });
});
